export { default } from './BrandCard'
