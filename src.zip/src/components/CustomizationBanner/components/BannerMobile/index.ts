export { default } from './BannerMobile'
