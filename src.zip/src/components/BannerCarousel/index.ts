export { default } from './BannerCarousel'
