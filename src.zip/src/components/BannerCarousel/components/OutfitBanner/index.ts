export { default } from './OutfitBanner'
