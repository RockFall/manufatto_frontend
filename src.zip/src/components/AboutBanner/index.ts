export { default } from './AboutBanner'
