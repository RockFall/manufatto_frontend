export { default } from './AboutFooter'
