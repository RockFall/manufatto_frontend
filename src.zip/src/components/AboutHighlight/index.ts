export { default } from './AboutHighlight'
