export { default } from './DetailsTabs'
