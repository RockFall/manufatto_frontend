export { default as DetailsTabs } from './DetailsTabs'
export { default as ProductData } from './ProductData'
