export { default } from './ProductDetails'
