export { default as ProductDetails } from './ProductDetails'
export { default as ProductDetailsMobile } from './ProductDetailsMobile'
