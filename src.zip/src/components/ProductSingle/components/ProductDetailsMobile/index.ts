export { default } from './ProductDetailsMobile'
