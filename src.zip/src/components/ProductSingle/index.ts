export { default } from './ProductSingle'
