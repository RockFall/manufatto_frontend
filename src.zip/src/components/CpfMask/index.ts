export { default } from './CpfMask'
