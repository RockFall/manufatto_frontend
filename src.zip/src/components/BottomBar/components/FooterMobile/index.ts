export { default } from './FooterMobile'
