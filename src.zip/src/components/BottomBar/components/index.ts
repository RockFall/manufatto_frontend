export { default as Footer } from './Footer'
export { default as FooterMobile } from './FooterMobile'
