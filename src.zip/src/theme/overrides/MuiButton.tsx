/*import { Overrides } from '@mui/material/styles/overrides'

const MuiButton: Overrides['MuiButton'] = {
  outlined: {
    boxSizing: 'border-box',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '12px',
    width: '200px',
    height: '58px',
    color: '#6F6C6B',
    border: '1px solid #6F6C6B',
    textTransform: 'uppercase',
    fontFamily: "Suisse Int\\'l",
    fontStyle: 'normal',
    borderRadius: '0px',

    '&:hover': {
      backgroundColor: '#F3F3F3',
    },
    '&:active': {
      backgroundColor: '#C1BBA7',
    },
  },
  contained: {
    boxSizing: 'border-box',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '12px',
    width: '200px',
    height: '58px',
    backgroundColor: '#1D1D1F',
    textTransform: 'uppercase',
    fontFamily: "Suisse Int\\'l",
    fontStyle: 'normal',
    color: '#FFFFFF',
    borderRadius: '0px',

    '&:hover': {
      backgroundColor: '#C1BBA7',
      color: '#1D1D1F',
    },
    '&:active': {
      backgroundColor: '#EBE9DF',
      color: '#1D1D1F',
    },
  },
}

export default MuiButton
*/