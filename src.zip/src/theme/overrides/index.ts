/*import { Overrides } from '@mui/material/styles/overrides'
import MuiButton from './MuiButton'

const overrides: Overrides = {
  MuiButton,
}

export default overrides*/
