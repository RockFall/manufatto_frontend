export { default as useStore } from './configureStore'
